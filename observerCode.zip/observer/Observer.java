abstract class Observer {
    protected Theme theme ;
    public abstract void modifier();
}